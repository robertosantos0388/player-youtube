PLAYER YOUTUBE DINÂMICO — PACOTE PARA GITHUB PAGES

Arquivos:
- index.html: página de teste com campo para link/ID do YouTube e iframe dinâmico.

Teste local realizado:
- Sintaxe JavaScript: PASSOU
- 7 testes funcionais: PASSARAM
  1. ID direta
  2. URL youtube.com/watch?v=...
  3. URL curta youtu.be/...
  4. URL /shorts/...
  5. rejeição de domínio inválido
  6. rejeição de ID malformada
  7. inicialização pelo parâmetro ?v=

IMPORTANTE:
Esses testes validam a lógica da página, não garantem que cada vídeo permita incorporação nem que o player toque em todos os navegadores.
A página online existente ainda precisa ser atualizada: testes remotos mostraram que ela ignora ?v= e mantém o vídeo fixo.

Publicação:
1. Crie um repositório público no GitHub.
2. Envie index.html para a raiz do repositório.
3. Em Settings > Pages, selecione Deploy from a branch, branch main, pasta /(root), e salve.
4. Aguarde a URL do GitHub Pages e teste com ?v=jNQXAC9IVRw.
